<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_airi_preset_home_05()
{
    return array(
        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_height',
            'value' => '120px'
        ),
    );
}