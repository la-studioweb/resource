<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_home_01()
{
    return array(
        
        array(
            'key' => 'header_layout',
            'value' => '4'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '3col363'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'image'     => '//zyra.la-studioweb.com/wp-content/uploads/2017/11/ft-bg.jpg',
                'size'      => 'cover',
                'repeat'    => 'no-repeat',
                'position'  => 'center center'
            )
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '80px',
                'padding_bottom' => '20px',
            )
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'la_zyra/filter/footer_column_1',
            'value' => 'demo-01-footer-column-1'
        ),
        array(
            'filter_name' => 'la_zyra/filter/footer_column_2',
            'value' => 'demo-01-footer-column-2'
        ),
        array(
            'filter_name' => 'la_zyra/filter/footer_column_3',
            'value' => 'demo-01-footer-column-3'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
#colophon .widget_media_image{
    margin-top: -30px;
    margin-bottom: 20px;
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}