<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_home_08()
{
    return array(

        array(
            'key' => 'header_layout',
            'value' => '7'
        ),
        array(
            'key' => 'header_full_width|header_transparency|header_sticky',
            'value' => 'no'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'custom'
        ),
        array(
            'key' => 'use_custom_header_top',
            'value' => '<div class="text-center text-color-secondary font-size-20">
    <span class="padding-right-20"><i class="three-font-family">End of Season</i></span><span class="font-weight-500">Sale off 50%</span>
</div>'
        ),

        array(
            'key' => 'header_access_icon',
            'value' => array(
                array(
                    'type' => 'dropdown_menu',
                    'menu_id' => 57,
                    'icon' => 'dl-icon-user1',
                    'el_class' => 'big-icon'
                ),
                array(
                    'type' => 'cart',
                    'icon' => 'dl-icon-cart24-1',
                    'el_class' => 'big-icon'
                )
            )
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.site-header-top.use-custom-html{
    background-color: #93ddff;
    background-image: -moz-linear-gradient(180deg, star 0%, #fabb98 100%);
    background-image: -webkit-linear-gradient(180deg, #93ddff 0%, #fabb98 100%);
    background-image: -ms-linear-gradient(180deg, #93ddff 0%, #fabb98 100%);
    padding-top: 14px;
    padding-bottom: 14px;
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}