<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_home_05()
{
    return array(

        array(
            'key' => 'header_full_width|header_transparency',
            'value' => 'no'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'image'     => '//zyra.la-studioweb.com/wp-content/uploads/2017/11/ft-bg-h2.jpg',
                'size'      => 'cover',
                'repeat'    => 'no-repeat',
                'position'  => 'center center'
            )
        )
    );
}