<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_blog_05(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'blog_masonry',
            'value' => 'off'
        ),
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_5'
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg'   => '2',
                'lg'    => '2',
                'md'    => '2',
                'sm'    => '1',
                'xs'    => '1',
                'mb'    => '1'
            )
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '570x340'
        ),
        array(
            'key' => 'blog_item_space',
            'value' => 'default'
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => 20
        ),
        array(
            'key' => 'main_space',
            'value' => array(
                'top' => 100,
                'bottom' => 100
            )
        ),
        array(
            'key' => 'page_title_bar_layout_blog_global',
            'value' => 'yes'
        ),
        array(
            'filter_name' => 'la_zyra/filter/page_title',
            'value' => '<header><div class="page-title h3">Blog Style 05</div></header>'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '

                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        ),
    );
}