<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_la_zyra_preset_home_11()
{
    return array(

        array(
            'key' => 'logo|logo_mobile',
            'value' => '1456'
        ),

        array(
            'key' => 'logo_2x|logo_mobile_2x',
            'value' => '1457'
        ),

        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'header_height|header_sticky_height',
            'value' => '120'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'custom'
        ),
        array(
            'key' => 'use_custom_header_top',
            'value' => '[rev_slider alias="home-11"]'
        ),


        /** Color
         *
         */

        array(
            'key' => 'primary_color',
            'value' => '#f5b324'
        ),

        array(
            'key' => 'header_background',
            'value' => array(
                'color' => '#232324'
            )
        ),

        array(
            'key' => 'header_text_color|header_link_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'header_link_hover_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'mm_lv_1_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_bg_color',
            'value' => '#232324'
        ),
        array(
            'key' => 'mm_lv_1_hover_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'mm_lv_1_hover_bg_color',
            'value' => '#f5b324'
        ),
        array(
            'key' => 'header_mb_background',
            'value' => '#232324'
        ),
        array(
            'key' => 'header_mb_text_color',
            'value' => '#fff'
        ),

        array(
            'filter_name' => 'la_zyra/setting/option/get_la_custom_css',
            'filter_func' => function( $value ){
                $value .= '
.site-header .site-header-outer .header_component.la_compt_iem.la_com_action--aside_header > .component-target{
    background-color: #fff;
    color: #232324;
}
.site-main-nav .main-menu > li > a:before{
    content: "";
    display: block !important;
    border: none;
    background-color: inherit;
    bottom: -40px !important;
    left: 0 !important;
    right: 0 !important;
    top: -40px !important;
    position: absolute !important;
    z-index: -1;
    height: auto;
}
.site-main-nav .main-menu > li > a:after {
    display:none;
}
.header-v2 .site-header .mega-menu > li {
    padding: 0;
}
.site-main-nav .main-menu > li > a {
    padding: 5px 20px;
}
                ';

                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 3
        )
    );
}