<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_payna_preset_home_17()
{
    return array(
        array(
            'key' => 'header_layout',
            'value' => 'pre-header-03'
        ),
        array(
            'filter_name' => 'payna/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                                @media (min-width: 1200px){
                                    body{
                                        background-image: url(https://payna.la-studioweb.com/wp-content/uploads/2019/02/header-bg-17.jpg);
                                        background-position: top center !important;
                                        background-size: 100% auto !important;
                                        background-repeat: no-repeat !important;
                                    } 
                                    .lahfb-area .lahfb-header-woo-cart-toggle .la-cart-modal-icon .header-cart-count-icon {
                                        background-color: #DE3535;
                                        color: #fff;
                                        border: none;
                                    }
                                }                   
                                @media (min-width: 1600px){
                                    
                                    .site-footer{
                                        max-width: calc(100% - 160px);
                                        margin: auto;
                                        overflow: hidden;
                                        margin-bottom: 80px;
                                    }
                                }
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}