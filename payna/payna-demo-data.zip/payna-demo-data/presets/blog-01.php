<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_payna_preset_blog_01()
{
    return array(

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'layout_blog',
            'value' => 'col-2cl'
        ),

        array(
            'key' => 'blog_design',
            'value' => 'grid_3'
        ),
        array(
            'key' => 'blog_thumbnail_height_mode',
            'value' => 'custom'
        ),
        array(
            'key' => 'blog_thumbnail_height_custom',
            'value' => '50%'
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg' => '1',
                'lg' => '1',
                'md' => '1',
                'sm' => '1',
                'xs' => '1',
                'mb' => '1'
            )
        ),
        array(
            'filter_name' => 'payna/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                    .blog__item.grid-item {
                        padding-top: 0;
                        padding-bottom: 0;
                    }
                    @media (min-width: 1400px){
                         body.payna-body .site-main {
                             padding-top: 120px;
                             padding-bottom: 70px;
                         }
                    }
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}