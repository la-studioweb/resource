<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_payna_preset_home_18()
{
    return array(
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'header_layout',
            'value' => 'pre-header-09'
        ),
        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),
        array(
            'key' => 'primary_color',
            'value' => '#bdbd74'
        ),
        array(
            'filter_name' => 'payna/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                               footer a:hover{
                                color: #bdbd74 !important;
                               }
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )

    );
}