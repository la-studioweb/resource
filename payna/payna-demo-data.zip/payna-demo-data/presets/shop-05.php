<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_payna_preset_shop_05()
{
    return array(

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'header_layout',
            'value' => 'pre-header-03'
        ),

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'main_full_width_archive_product',
            'value' => 'yes'
        ),
        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => '210',
                'bottom' => '70'
            )
        ),
        array(
            'key' => 'shop_sidebar',
            'value' => 'payna_widget_area_2'
        ),

        array(
            'key' => 'product_per_page_allow',
            'value' => ''
        ),

        array(
            'key' => 'product_per_page_default',
            'value' => 10
        ),

        array(
            'key' => 'shop_catalog_display_type',
            'value' => 'grid'
        ),
        array(
            'key' => 'shop_catalog_grid_style',
            'value' => '7'
        ),
        array(
            'key' => 'active_shop_masonry',
            'value' => 'on'
        ),
        array(
            'key' => 'product_masonry_container_width',
            'value' => 1760
        ),
        array(
            'key' => 'product_masonry_item_width',
            'value' => 425
        ),
        array(
            'key' => 'product_masonry_item_height',
            'value' => 570
        ),
        array(
            'key' => 'shop_masonry_column_type',
            'value' => 'custom'
        ),
        array(
            'key' => 'enable_shop_masonry_custom_setting',
            'value' => 'on'
        ),
        array(
            'key' => 'shop_masonry_item_setting',
            'value' =>
                array (
                    1 =>
                        array (
                            'size_name' => '1x Width + 1x Height',
                            'w' => '1',
                            'h' => '1',
                        ),
                    2 =>
                        array (
                            'size_name' => '1x Width + 1x Height',
                            'w' => '1',
                            'h' => '1',
                        ),
                    3 =>
                        array (
                            'size_name' => '2x Width + 1x Height',
                            'w' => '2',
                            'h' => '1',
                        ),
                    4 =>
                        array (
                            'size_name' => '2x Width + 1x Height',
                            'w' => '2',
                            'h' => '1',
                        ),
                    5 =>
                        array (
                            'size_name' => '1x Width + 1x Height',
                            'w' => '1',
                            'h' => '1',
                        ),
                    6 =>
                        array (
                            'size_name' => '1x Width + 1x Height',
                            'w' => '1',
                            'h' => '1',
                        ),
                    7 =>
                        array (
                            'size_name' => '1x Width + 1x Height',
                            'w' => '1',
                            'h' => '1',
                        ),
                    8 =>
                        array (
                            'size_name' => '1x Width + 0.5x Height',
                            'w' => '1',
                            'h' => '0.5',
                        ),
                    9 =>
                        array (
                            'size_name' => '2x Width + 1x Height',
                            'w' => '2',
                            'h' => '1',
                        ),
                    10 =>
                        array (
                            'size_name' => '2x Width + 0.5x Height',
                            'w' => '1',
                            'h' => '0.5',
                        ),
                    11 =>
                        array (
                            'size_name' => '2x Width + 1x Height',
                            'w' => '2',
                            'h' => '1',
                        ),
                    12 =>
                        array (
                            'size_name' => '2x Width + 1x Height',
                            'w' => '2',
                            'h' => '1',
                        ),
                )

        ),


        array(
            'key' => 'woocommerce_shop_masonry_custom_columns',
            'value' => array(
                'md' => 2,
                'sm' => 1,
                'xs' => 1,
                'mb' => 1
            )
        ),

        array(
            'filter_name' => 'payna/filter/page_title',
            'value' => '<header><h1 class="page-title">Shop Metro</h1></header>'
        ),

        array(
            'filter_name' => 'payna/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                    #section_page_header{
                        background: #FFEBEB url("/wp-content/themes/payna/assets/images/bg-title-shop.jpg") no-repeat center center;
                        background-size: cover;
                        
                    }
                    .product_item .product_item--thumbnail-holder .pic-m-fallback {
                        background-position: center top;
                    }
                    li.product_item {
                        padding: 10px;
                    }
                    .wc-toolbar-container {
                        padding-left: 20px;
                        padding-right: 20px;
                    }
                    .la-shop-products .la-pagination{
                        margin-top: 80px;
                    }
                    @media (max-width: 767px){
                       
                        .site-main {
                            padding-top: 30px !important;
                        }
                    }
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}