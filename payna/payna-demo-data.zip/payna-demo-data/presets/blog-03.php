<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_payna_preset_blog_03()
{
    return array(

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),


        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_4'
        ),
        array(
            'key' => 'blog_thumbnail_height_mode',
            'value' => 'custom'
        ),
        array(
            'key' => 'blog_thumbnail_height_custom',
            'value' => '80%'
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => '18'
        ),
        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg' => '3',
                'lg' => '3',
                'md' => '2',
                'sm' => '2',
                'xs' => '1',
                'mb' => '1'
            )
        ),


        array(
            'filter_name' => 'payna/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                            .la-pagination ul{
                                text-align: center;
                                    margin-top: 60px;
                            }
                            .blog__item.grid-item {
                                padding-top: 0;
                                padding-bottom: 0;
                            }
                            .grid-items .grid-item{
                                padding-left: 40px;
                                padding-right: 40px;
                            }
                            .post_format-post-format-quote .loop__item__thumbnail--bkg {
                                padding-bottom: 80% !important; 
                            }
                            @media (min-width: 1400px){
                                .container {
                                    width: 100%;
                                    padding-left: 80px;
                                    padding-right: 80px;
                                }
                                body.payna-body .site-main {
                                    padding-top: 120px;
                                    padding-bottom: 70px;
                                }
                            }
                            @media (max-width: 991px){
                                .grid-items .grid-item {
                                     padding-left: 20px;
                                    padding-right: 20px;
                                }
                            }
                    
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}