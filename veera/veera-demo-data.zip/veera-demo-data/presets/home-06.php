<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_veera_preset_home_06()
{
    return array(

        array(
            'key' => 'enable_header_top',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_top_elements',
            'value' => array(
                array(
                    'type' => 'link_text',
                    'icon' => 'fa fa-envelope-o',
                    'text' => 'info@la-studioweb.com',
                    'link' => 'mailto:info@la-studioweb.com'
                ),
                array (
                    'type' => 'text',
                    'icon' => 'fa fa-clock-o',
                    'text' => '9:00 AM - 21:00 PM'
                ),

                array (
                    'type' => 'dropdown_menu',
                    'text' => 'Language',
                    'menu_id' => 73,
                    'icon' => 'fa fa-globe',
                    'el_class' => 'la_com_dropdown_show_arrow la_com_dropdown_language'
                ),
                array (
                    'type' => 'dropdown_menu',
                    'text' => 'Currency',
                    'icon' => 'fa fa-dollar',
                    'menu_id' => 74,
                    'el_class' => 'la_com_dropdown_show_arrow la_com_dropdown_currency'
                ),
                array(
                    'type' => 'dropdown_menu',
                    'text' => 'My Account',
                    'icon' => 'fa fa-user',
                    'menu_id' => 72,
                    'el_class' => 'la_com_dropdown_show_arrow pull-right'
                ),
            )
        ),
        array(
            'key' => 'header_layout',
            'value' => '9'
        ),

        array(
            'key' => 'header_height',
            'value' => '120px'
        ),

        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),

        array(
            'key' => 'enable_searchbox_header',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_top_text_color|header_top_link_color',
            'value' => '#8D8D8D'
        ),

        array(
            'key' => 'header_access_icon_1',
            'value' => array(
                array(
                    'type' => 'cart',
                    'icon' => 'dl-icon-cart4',
                    'text' => 'Your cart',
                    'link' => '#',
                    'el_class' => ''
                )
            )
        ),

        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),

        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top'       => '40px',
                'padding_bottom'    => '0'
            )
        ),

        array(
            'filter_name' => 'veera/filter/footer_column_1',
            'value' => 'footer-layout-3-column-1'
        ),
        array(
            'filter_name' => 'veera/filter/footer_column_2',
            'value' => 'footer-layout-3-column-2'
        ),
        array(
            'filter_name' => 'veera/filter/footer_column_3',
            'value' => 'footer-layout-3-column-3'
        ),

        array(
            'filter_name' => 'veera/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.site-header-top{
    font-size: 12px;
    border-bottom: 1px solid #F9F9F9;
    padding-top: 0;
    padding-bottom: 0;
}
.site-main-nav .main-menu > li > a{
    font-weight: 400;
}
.header-v9 .header-main .searchform-wrapper {
    width: 370px;
    max-width: 100%;
}
.site-footer .widget .widget-title{
    font-size: 14px;
}
.la-footer-3col444 .footer-column-inner {
    max-width: 100%;
    margin: 0 auto;
    width: 270px;
}
.la-footer-3col444 .footer-column-1 .footer-column-inner{
    float: left;
}
.la-footer-3col444 .footer-column-3 .footer-column-inner{
    float: right;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '
<div class="row font-size-11">
	<div class="col-xs-12 col-sm-4 xs-text-center text-color-secondary">
		[wp_nav_menu menu_id="34"]
	</div>
	<div class="col-xs-12 col-sm-4 text-center">
		© 2018 Veera All rights reserved
	</div>
	<div class="col-xs-12 col-sm-4 text-right xs-text-center">
		<img src="//veera.la-studioweb.com/wp-content/themes/veera/assets/images/payments.png" alt="payment">
	</div>
</div>
'
        ),
    );
}