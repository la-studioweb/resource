<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_mantis_preset_home_07()
{
    return array(
        array(
            'key' => 'header_height',
            'value' => '110px'
        ),
        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'no'
        ),

        array(
            'key' => 'header_access_icon_1',
            'value' => array(
                array(
                    'type' => 'search_1',
                    'el_class' => ''
                ),
                array(
                    'type' => 'link_text',
                    'icon' => 'dl-icon-user12',
                    'link' => '#',
                    'text' => 'Sign In',
                    'el_class' => 'hide-when-logged'
                ),
                array(
                    'type' => 'link_text',
                    'icon' => 'dl-icon-user12',
                    'link' => '#',
                    'text' => 'Logout',
                    'el_class' => 'show-when-logged'
                ),
                array(
                    'type' => 'cart',
                    'icon' => 'dl-icon-cart1',
                    'link' => '#',
                    'el_class' => ''
                ),
                array(
                    'type' => 'aside_header',
                    'icon' => 'dl-icon-menu1',
                    'el_class' => ''
                )
            )
        ),


        array(
            'filter_name' => 'mantis/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.site-main-nav .main-menu > li > a {
    text-transform: none;
    font-weight: 600;
    font-size: 18px;
}
.mega-menu .popup{
    font-size: 14px;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )

    );
}