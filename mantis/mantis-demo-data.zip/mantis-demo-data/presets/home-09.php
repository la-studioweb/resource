<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_mantis_preset_home_09()
{
    return array(

        array(
            'filter_name' => 'mantis/setting/logo/transparency',
            'filter_func' => function( $value ){
                if(class_exists('Mantis')){
                    $value = Mantis::$template_dir_url . '/assets/images/logo-white.svg';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 1
        ),
        array(
            'key' => 'header_height',
            'value' => '100px'
        ),
        array(
            'key' => 'header_layout',
            'value' => '2'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'no'
        ),

        array(
            'key' => 'transparency_header_link_hover_color|transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'header_access_icon_1',
            'value' => array(
                array(
                    'type' => 'search_1',
                    'el_class' => ''
                ),
                array(
                    'type' => 'cart',
                    'icon' => 'dl-icon-cart1',
                    'link' => '#',
                    'el_class' => ''
                ),
                array(
                    'type' => 'aside_header',
                    'icon' => 'dl-icon-menu1',
                    'el_class' => ''
                )
            )
        ),

        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),

        array(
            'key' => 'footer_full_width',
            'value' => 'no'
        ),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#1C1C1C'
            )
        ),
        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#1C1C1C'
        ),

        array(
            'key' => 'footer_text_color|footer_heading_color|footer_link_color|footer_copyright_text_color|footer_copyright_link_color',
            'value' => '#828282'
        ),

        array(
            'key' => 'footer_link_hover_color|footer_copyright_link_hover_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top'       => '60px',
                'padding_bottom'    => '60px',
                'border_bottom'     => '1px',
                'border_style'      => 'solid',
                'border_color'      => '#363636',
            )
        ),

        array(
            'key' => 'footer_copyright',
            'value' => '
<div class="row">
	<div class="col-xs-12 col-sm-8 xs-text-center">
		[wp_nav_menu menu_id="76"]
	</div>
	<div class="col-xs-12 col-sm-4 text-right xs-text-center">
		© 2018 Mantis All rights reserved
	</div>
</div>
'
        ),


        array(
            'filter_name' => 'mantis/filter/footer_column_1',
            'value' => 'home-01-footer-01'
        ),
        array(
            'filter_name' => 'mantis/filter/footer_column_2',
            'value' => 'home-01-footer-02'
        ),
        array(
            'filter_name' => 'mantis/filter/footer_column_3',
            'value' => 'home-01-footer-03'
        ),

        array(
            'filter_name' => 'mantis/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.site-main-nav .main-menu > li > a {
    text-transform: none;
    font-weight: 600;
    font-size: 18px;
}
.mega-menu .popup{
    font-size: 14px;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}