<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_mantis_preset_shop_metro()
{
    return array(

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),

        array(
            'key' => 'woocommerce_toggle_grid_list',
            'value' => 'no'
        ),

        array(
            'key' => 'product_per_page_allow',
            'value' => ''
        ),

        array(
            'key' => 'active_shop_masonry',
            'value' => 'on'
        ),

        array(
            'key' => 'shop_catalog_grid_style',
            'value' => '2'
        ),

        array(
            'key' => 'shop_masonry_column_type',
            'value' => 'custom'
        ),

        array(
            'key' => 'product_masonry_container_width',
            'value' => '1760'
        ),

        array(
            'key' => 'product_masonry_item_width',
            'value' => '425'
        ),

        array(
            'key' => 'product_masonry_item_height',
            'value' => '550'
        ),

        array(
            'key' => 'shop_item_space',
            'value' => '20'
        ),

        array(
            'key' => 'woocommerce_shop_masonry_custom_columns',
            'value' => array(
                'md' => 3,
                'sm' => 2,
                'xs' => 2,
                'mb' => 1
            )
        ),

        array(
            'key' => 'enable_shop_masonry_custom_setting',
            'value' => 'on'
        ),

        array(
            'key' => 'shop_masonry_item_setting',
            'value' => array(
                0 => array(
                    'size_name' => '2x width + 1x height',
                    'w' => '2',
                    'h' => '1'
                ),
                1 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                2 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                3 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                4 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                5 => array(
                    'size_name' => '2x width + 1x height',
                    'w' => '2',
                    'h' => '1'
                ),
                6 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                7 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                8 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                9 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                10 => array(
                    'size_name' => '2x width + 1x height',
                    'w' => '2',
                    'h' => '1'
                ),
                11 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
                12 => array(
                    'size_name' => '1x width + 1x height',
                    'w' => '1',
                    'h' => '1'
                ),
            )
        ),


        array(
            'filter_name' => 'mantis/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.wc-toolbar-container {
    margin-bottom: 10px;
}
.la-shop-products .la-pagination {
    margin-top: 50px;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),

        array(
            'filter_name' => 'mantis/filter/page_title',
            'value' => '<header><h1 class="page-title h1">Shop Metro</h1></header>'
        ),
    );
}