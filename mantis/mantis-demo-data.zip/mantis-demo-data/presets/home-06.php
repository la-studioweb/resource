<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_mantis_preset_home_06()
{
    return array(

        array(
            'key' => 'header_layout',
            'value' => '6'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'yes'
        ),

        array(
            'key' => 'header_top_elements',
            'value' => array(
                array(
                    'type' => 'search_1',
                    'el_class' => ''
                ),
                array(
                    'type' => 'link_text',
                    'icon' => 'dl-icon-user12',
                    'link' => '#',
                    'text' => 'Sign In',
                    'el_class' => 'hide-when-logged'
                ),
                array(
                    'type' => 'link_text',
                    'icon' => 'dl-icon-user12',
                    'link' => '#',
                    'text' => 'Logout',
                    'el_class' => 'show-when-logged'
                ),
                array(
                    'type' => 'cart',
                    'icon' => 'dl-icon-cart1',
                    'link' => '#',
                    'el_class' => ''
                )
            )
        ),

        array(
            'key' => 'header_access_icon_1',
            'value' => array(

            )
        ),


        array(
            'filter_name' => 'mantis/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.header-v6 #masthead_aside{
    box-shadow: none;
}
.header-v6 .header--aside .mega-menu > li > a {
    text-transform: none;
    font-weight: normal;
    font-size: 16px;
    padding-top: 5px;
    padding-bottom: 5px;
}
.header-v6 .mega-menu .popup {
    font-size: inherit;
}
.header-v6 #masthead_aside .site-header-inner {
    min-height: 95vh;
}
.header-v6 #masthead_aside .site-header-inner:not(.is_stuck){
    position: relative;
}
.header-v6 #masthead_aside .header-right {
    margin-top: 10vh;
}
.header-v6 #masthead_aside .header-bottom {
    position: absolute;
    bottom: 20px;
    padding-top: 0;
}

@media(min-width: 1500px){
    .header-v6 .header--aside .mega-menu > li > a {
        font-size: 24px;
        padding-top: 13px;
        padding-bottom: 13px;
    }
    .header-v6 #masthead_aside .header-bottom {
        bottom: 5%;
    }
}

';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),


        array(
            'filter_name' => 'mantis/filter/header_sidebar_widget_bottom',
            'value' => 'home-06-header-bottom'
        ),
    );
}