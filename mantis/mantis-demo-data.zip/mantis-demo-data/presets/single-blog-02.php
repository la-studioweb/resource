<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_mantis_preset_single_blog_02()
{
    return array(


        array(
            'key' => 'blog_related_design',
            'value' => '2'
        ),

        array(
            'key' => 'blog_related_max_post',
            'value' => '2'
        )

    );
}