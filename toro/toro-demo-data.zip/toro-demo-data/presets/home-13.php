<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_toro_preset_home_13()
{
    return array(

        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),

        array(
            'key' => 'header_layout',
            'value' => 'pre-header-vertical-simple-02'
        )
    );
}