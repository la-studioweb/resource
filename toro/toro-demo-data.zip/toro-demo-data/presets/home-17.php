<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_toro_preset_home_17()
{
    return array(
        array(
            'key' => 'header_layout',
            'value' => 'pre-header-toggle-01'
        ),
    );
}