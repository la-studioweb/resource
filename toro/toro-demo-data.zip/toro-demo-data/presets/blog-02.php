<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_toro_preset_blog_02()
{
    return array(

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),


        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'blog_thumbnail_height_custom',
            'value' => '45%'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'grid_3'
        ),


        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg' => '1',
                'lg' => '1',
                'md' => '1',
                'sm' => '1',
                'xs' => '1',
                'mb' => '1'
            )
        ),
        array(
            'filter_name' => 'toro/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.la-pagination {
    max-width: 870px;
    margin: 0px auto;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}