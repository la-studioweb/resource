<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_toro_preset_blog_08()
{
    return array(

        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'blog_design',
            'value' => 'grid_5'
        ),

        array(
            'key' => 'blog_thumbnail_height_mode',
            'value' => 'custom'
        ),

        array(
            'key' => 'blog_thumbnail_height_custom',
            'value' => '62%'
        ),

        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => '210',
                'bottom' => '135'
            )
        ),

        array(
            'key' => 'page_title_bar_spacing_desktop_small',
            'value' => array(
                'top' => '210',
                'bottom' => '135'
            )
        ),

        array(
            'key' => 'blog_post_column',
            'value' => array(
                'xlg' => '3',
                'lg' => '3',
                'md' => '3',
                'sm' => '2',
                'xs' => '2',
                'mb' => '1'
            )
        ),

        array(
            'key' => 'blog_excerpt_length',
            'value' => 30
        ),

        array(
            'filter_name' => 'toro/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '

';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}