<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_toro_preset_shop_detail_04()
{
    return array(

        array(
            'key' => 'woocommerce_product_page_design',
            'value' => '1'
        ),
        array(
            'key' => 'layout_single_product',
            'value' => 'col-2cl'
        ),
        array(
            'key' => 'main_full_width_single_product',
            'value' => 'yes'
        ),
        array(
            'key' => 'page_title_bar_layout',
            'value' => 'hide'
        ),
        array(
            'key' => 'products_sidebar',
            'value' => 'toro_widget_area_2'
        ),
        array(
            'filter_name' => 'toro/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                    .product--summary .la-custom-pright-02{
                        display: none;
                    }
    
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )

    );
}



