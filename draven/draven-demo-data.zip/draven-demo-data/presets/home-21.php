<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_21()
{
    return array(

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'header_sticky',
            'value' => 'auto'
        ),

        array(
            'key' => 'logo_transparency',
            'value' => '19'
        ),

        array(
            'key' => 'header_layout',
            'value' => 'pre-header-08'
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.lahfb-nav-wrap .menu > li.menu-item > a {
    font-weight: normal;
}
@media(min-width: 1700px){
    .lahfb-icon-wrap .lahfb-icon-element.hamburger-op-icon {
        width: 80px;
        height: 80px;
    }
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),

    );
}