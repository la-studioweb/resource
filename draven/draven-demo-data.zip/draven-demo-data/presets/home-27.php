<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_27()
{
    return array(

        array(
            'key' => 'primary_color',
            'value' => '#FFD600'
        ),

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'header_sticky',
            'value' => 'no'
        ),

        array(
            'key' => 'header_layout',
            'value' => 'pre-header-03'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '5701'
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.lahfb-desktop-view .lahfb-nav-wrap .menu > li.menu-item > a {
    text-transform: uppercase;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
    );
}