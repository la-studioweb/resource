<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_home_06()
{
    return array(
        array(
            'key' => 'header_layout',
            'value' => 'pre-header-01'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '2758'
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
.la-footer-builder .elementor-section.elementor-section-boxed > .elementor-container {
    max-width: 100% !important;
}
@media(min-width: 1600px){
    .lahfb-wrap .lahfb-desktop-view .lahfb-row1-area:not(.lahfb-vertical) {
        height: 160px;
    }
    img.lahfb-logo{
        width: 80px;
    }
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),

    );
}