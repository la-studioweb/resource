<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_draven_preset_blog_02()
{
    return array(

        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'blog_design',
            'value' => 'grid_2'
        ),

        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => '210',
                'bottom' => '135'
            )
        ),

        array(
            'key' => 'page_title_bar_spacing_desktop_small',
            'value' => array(
                'top' => '210',
                'bottom' => '135'
            )
        ),

        array(
            'filter_name' => 'draven/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
#section_page_header{
    background-image: linear-gradient(-134deg, #EB3F5C 0%, #C86DD7 100%);
}
#section_page_header,
#section_page_header a,
#section_page_header .page-title{
    color: #fff;
}
div#main {
    background-color: #F9F9F9;
}
.sidebar-inner .widget {
    background-color: #fff;
}
.sidebar-inner .widget .search-form .search-field {
    border-color: transparent;
}
.sidebar-inner .widget_tag_cloud,
.sidebar-inner .widget_recent_entries,
.sidebar-inner .widget_categories {
    padding: 35px 30px;
}
.sidebar-inner .widget .widget-title {
    font-size: 18px;
}
.widget_recent_entries .pr-item .pr-item--left {
    width: 70px;
    height: 70px;
}
.widget_recent_entries .pr-item .pr-item--right a {
    font-size: 16px;
    margin-top: 0;
}
.widget_recent_entries .pr-item {
    border: none;
    margin-bottom: 0;
    padding-bottom: 5px;
}
.sidebar-inner .widget select {
    border-color: transparent;
    padding: 10px 30px;
    margin-bottom: 20px;
}
.sidebar-inner .widget_archive .widget-title {
    padding: 30px 30px 0;
    margin-bottom: 2rem;
}
.sidebar-inner .widget {
    margin-bottom: 30px;
}
@media(min-width: 1500px){
    div#main {
        padding-top: 100px;
        padding-bottom: 100px;
    }
}

.enable-header-transparency #lastudio-header-builder .lahfb-element > a:hover {
    color: inherit;
}
';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        )
    );
}