<?php

function negan_get_demo_array($dir_url, $dir_path){

    $demo = array(
        'demo-01' => array(
            'title' 		=> 'Demo 01',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-01.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-01.dat',
            'preview'		=> $dir_url  . 'demo-01.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 01',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-01',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-01/'
        ),
        'demo-02' => array(
            'title' 		=> 'Demo 02',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-02.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-2.wie',
            'option' 		=> $dir_path . 'demo-02.dat',
            'preview'		=> $dir_url  . 'demo-02.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 02',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-02',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-02/'
        ),
        'demo-03' => array(
            'title' 		=> 'Demo 03',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-03.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-2.wie',
            'option' 		=> $dir_path . 'demo-03.dat',
            'preview'		=> $dir_url  . 'demo-03.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 03',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-03',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-03/'
        ),
        'demo-04' => array(
            'title' 		=> 'Demo 04',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-2.wie',
            'option' 		=> $dir_path . 'demo-04.dat',
            'preview'		=> $dir_url  . 'demo-04.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 04',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-04',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-04/'
        ),
        'demo-05' => array(
            'title' 		=> 'Demo 05',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-05.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-05.dat',
            'preview'		=> $dir_url  . 'demo-05.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 05',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-05',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-05/'
        ),
        'demo-06' => array(
            'title' 		=> 'Demo 06',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-06.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-06.dat',
            'preview'		=> $dir_url  . 'demo-06.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 06',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-06',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-06/'
        ),
        'demo-07' => array(
            'title' 		=> 'Demo 07',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-07.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-07.dat',
            'preview'		=> $dir_url  . 'demo-07.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 07',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-07',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-07/'
        ),
        'demo-08' => array(
            'title' 		=> 'Demo 08',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-08.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-08.dat',
            'preview'		=> $dir_url  . 'demo-08.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 08',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-08',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-08/'
        ),
        'demo-09' => array(
            'title' 		=> 'Demo 09',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-09.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-2.wie',
            'option' 		=> $dir_path . 'demo-09.dat',
            'preview'		=> $dir_url  . 'demo-09.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 09',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-09',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-09/'
        ),
        'demo-10' => array(
            'title' 		=> 'Demo 10',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-10.dat',
            'preview'		=> $dir_url  . 'demo-10.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 10',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-10',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-10/'
        ),
        'demo-11' => array(
            'title' 		=> 'Demo 11',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-11.dat',
            'preview'		=> $dir_url  . 'demo-11.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 11',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-11',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-11/'
        ),
        'demo-12' => array(
            'title' 		=> 'Demo 12',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'demo-12.zip',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-12.dat',
            'preview'		=> $dir_url  . 'demo-12.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 12',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-12',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-12/'
        ),
        'demo-13' => array(
            'title' 		=> 'Demo 13',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-13.dat',
            'preview'		=> $dir_url  . 'demo-13.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 13',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-13',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-13/'
        ),
        'demo-14' => array(
            'title' 		=> 'Demo 14',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-2.wie',
            'option' 		=> $dir_path . 'demo-14.dat',
            'preview'		=> $dir_url  . 'demo-14.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 14',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-14',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-14/'
        ),
        'demo-15' => array(
            'title' 		=> 'Demo 15',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-3.wie',
            'option' 		=> $dir_path . 'demo-15.dat',
            'preview'		=> $dir_url  . 'demo-15.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 15',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-15',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-15/'
        ),
        'demo-16' => array(
            'title' 		=> 'Demo 16',
            'category'      => 'demo',
            'content' 		=> $dir_path . 'negan-content.xml',
            'widget' 		=> $dir_path . 'widget-default.wie',
            'option' 		=> $dir_path . 'demo-16.dat',
            'preview'		=> $dir_url  . 'demo-16.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
                'second-nav' => 'Second Navigation',
                'account-nav' => 'Menu Account'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Demo 16',
                'page_for_posts' 	=> 'Blog',
                'woocommerce_shop_page_id'      => 'Shop',
                'woocommerce_cart_page_id'      => 'Cart',
                'woocommerce_checkout_page_id'  => 'Checkout',
                'woocommerce_myaccount_page_id' => 'My Account',
                'yith_wcwl_wishlist_page_id'    => 'Wishlist'
            ),
            'other_setting' => array(
                'shop_catalog_image_size' => array(
                    'width' => 270,
                    'height' => 390,
                    'crop' => true
                ),
                'shop_single_image_size' => array(
                    'width' => 470,
                    'height' => 600,
                    'crop' => true
                ),
                'shop_thumbnail_image_size' => array(
                    'width' => 75,
                    'height' => 95,
                    'crop' => true
                )
            ),
            'demo_preset'   => 'demo-16',
            'demo_url'      => 'http://negan.la-studioweb.com/demo-16/'
        )
    );

    return $demo;
}