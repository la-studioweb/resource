<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_shop_sidebar(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'layout_archive_product',
            'value' => 'col-2cl'
        ),
        array(
            'key' => 'page_title_bar_layout',
            'value' => 1
        ),
        array(
            'key' => 'page_title_bar_background',
            'value' => array(
                'image'     => '//negan.la-studioweb.com/wp-content/uploads/2017/06/demo-page-title-bar-bg.jpg',
                'position'  => 'center top',
                'size'      => 'cover',
                'color'     => '#000'
            )
        ),
        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => 60,
                'bottom' => 60
            )
        ),
        array(
            'key' => 'page_title_bar_heading_color',
            'value' => '#fff'
        ),
        array(
            'key'   => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 3,
                'lg' => 3,
                'md' => 3,
                'sm' => 2,
                'xs' => 2,
                'mb' => 1
            )
        ),
        array(
            'key'   => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),
        array(
            'filter_name' => 'negan/filter/page_title',
            'value' => '<header><div class="page-title h3">Shop Sidebar</div></header>'
        )
    );
}