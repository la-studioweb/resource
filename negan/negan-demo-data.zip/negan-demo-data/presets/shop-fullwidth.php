<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_shop_fullwidth(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'page_title_bar_layout',
            'value' => 4
        ),
        array(
            'key' => 'page_title_bar_background',
            'value' => array(
                'color' => '#f8f8f8'
            )
        ),
        array(
            'key' => 'page_title_bar_spacing',
            'value' => array(
                'top' => '75',
                'bottom' => '75'
            )
        ),
        array(
            'key'   => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => 5,
                'lg' => 5,
                'md' => 4,
                'sm' => 3,
                'xs' => 2,
                'mb' => 1
            )
        ),
        array(
            'key'   => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),
        array(
            'filter_name' => 'negan/filter/page_title',
            'value' => '<header><div class="page-title h3">Shop FullWidth</div></header>'
        )
    );
}