<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_shop_masonry_01(){
    return array(
        array(
            'key'   => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),
        array(
            'key'   => 'active_shop_masonry',
            'value' => 'on'
        ),
        array(
            'key'   => 'shop_masonry_column_type',
            'value' => 'default'
        ),
        array(
            'key'   => 'shop_catalog_grid_style',
            'value' => 4
        ),
        array(
            'filter_name' => 'negan/filter/page_title',
            'value' => '<header><div class="page-title h3">Shop Masonry</div></header>'
        )
    );
}