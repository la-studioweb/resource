<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_10(){
    return array(
        array(
            'key' => 'logo',
            'value' => 1144
        ),
        array(
            'key' => 'logo_2x',
            'value' => 1145
        ),
        array(
            'key' => 'logo_mobile',
            'value' => 1144
        ),
        array(
            'key' => 'logo_mobile_2x',
            'value' => 1145
        ),
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_layout',
            'value' => 6
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'hide'
        ),
        array(
            'key' => 'custom_header_text',
            'value' => '<div class="font-size-14 text-color-three three-font-family">Beautiful WooCommerce WordPress Theme</div>'
        ),

        array(
            'key' => 'offcanvas_background',
            'value' => '#232324'
        ),
        array(
            'key' => 'offcanvas_text_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'offcanvas_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'offcanvas_link_color',
            'value' => '#fff'
        ),

        array(
            'key' => 'header_mb_background',
            'value' => '#232324'
        ),
        array(
            'key' => 'header_mb_text_color',
            'value' => '#fff'
        ),

    );
}