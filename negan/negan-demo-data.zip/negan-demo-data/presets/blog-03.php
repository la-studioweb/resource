<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_blog_03(){
    return array(
        array(
            'key' => 'layout_blog',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'blog_design',
            'value' => 'list_2'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '570x390'
        ),
        array(
            'key' => 'blog_excerpt_length',
            'value' => 40
        ),
        array(
            'key' => 'main_space',
            'value' => array(
                'top' => 100,
                'bottom' => 100
            )
        ),
        array(
            'filter_name' => 'negan/filter/page_title',
            'value' => '<header><div class="page-title h3">Blog Classic</div></header>'
        )
    );
}