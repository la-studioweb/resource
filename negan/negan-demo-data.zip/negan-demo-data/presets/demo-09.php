<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_09(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_layout',
            'value' => 6
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'hide'
        ),
        array(
            'key' => 'custom_header_text',
            'value' => '<div class="font-size-14 text-color-three three-font-family">Beautiful WooCommerce WordPress Theme</div>'
        ),
        /** FOOTER **/
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#131313'
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'filter_name' => 'negan/filter/footer_column_1',
            'value' => 'footer-column-logo-white'
        ),
        array(
            'filter_name' => 'negan/filter/footer_column_5',
            'value' => 'footer-column-maps'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.footer-top { border-width: 0 }'
        )
    );
}