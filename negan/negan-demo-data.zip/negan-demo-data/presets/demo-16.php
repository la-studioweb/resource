<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_16(){
    return array(
        array(
            'key' => 'logo',
            'value' => 1144
        ),
        array(
            'key' => 'logo_2x',
            'value' => 1145
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 1144
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 1145
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),

        array(
            'key' => 'header_background',
            'value' => array(
                'color' => 'rgba(255,255,255,0)'
            )
        ),
        array(
            'key' => 'header_text_color|header_link_color|mm_lv_1_color',
            'value' => '#fff'
        )
    );
}