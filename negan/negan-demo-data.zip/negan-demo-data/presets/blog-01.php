<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_blog_01(){
    return array(
        array(
            'key' => 'main_space',
            'value' => array(
                'top' => 100,
                'bottom' => 100
            )
        ),
        array(
            'filter_name' => 'negan/filter/page_title',
            'value' => '<header><div class="page-title h3">Blog Sidebar</div></header>'
        )
    );
}