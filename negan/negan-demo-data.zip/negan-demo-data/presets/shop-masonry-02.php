<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_shop_masonry_02(){
    return array(
        array(
            'key'   => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ),
        array(
            'key'   => 'shop_catalog_grid_style',
            'value' => '5-2'
        ),
        array(
            'key'   => 'active_shop_masonry',
            'value' => 'on'
        ),
        array(
            'key'   => 'shop_masonry_column_type',
            'value' => 'custom'
        ),
        array(
            'key'   => 'product_per_page_allow',
            'value' => '10, 30, 30'
        ),
        array(
            'key'   => 'product_per_page_default',
            'value' => 10
        ),
        array(
            'key'   => 'shop_masonry_item_gap',
            'value' => '10'
        ),
        array(
            'key'   => 'product_masonry_item_width',
            'value' => 236
        ),
        array(
            'key'   => 'product_masonry_item_height',
            'value' => 250
        ),
        array(
            'key'   => 'enable_shop_masonry_custom_setting',
            'value' => 'on'
        ),
        array(
            'key'   => 'shop_masonry_item_setting',
            'value' => array(
                array(
                    'width' => '2',
                    'height' => '2'
                ),
                array(
                    'width' => '3',
                    'height' => '2'
                ),
                array(
                    'width' => '3',
                    'height' => '2'
                ),
                array(
                    'width' => '2',
                    'height' => '1'
                ),
                array(
                    'width' => '2',
                    'height' => '1'
                ),
                array(
                    'width' => '2',
                    'height' => '1'
                ),
                array(
                    'width' => '3',
                    'height' => '2'
                ),
                array(
                    'width' => '2',
                    'height' => '1'
                ),
                array(
                    'width' => '3',
                    'height' => '2'
                ),
                array(
                    'width' => '2',
                    'height' => '2'
                )
            )
        ),
        array(
            'filter_name' => 'negan/filter/page_title',
            'value' => '<header><div class="page-title h3">Shop Masonry 02</div></header>'
        )
    );
}