<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_14(){
    return array(
        array(
            'key' => 'header_layout',
            'value' => 3
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_top_elements',
            'value' => array(
                array(
                    'type' => 'text',
                    'icon' => 'fa fa-phone',
                    'text' => '+56.653.534',
                    'el_class' => ''
                ),
                array(
                    'type' => 'link_text',
                    'icon' => 'fa fa-envelope',
                    'text' => 'INFO@DOMAIN.COM',
                    'link' => 'mailto:info@domain.com',
                    'el_class' => 'hidden-xs'
                ),
                array(
                    'type' => 'text',
                    'icon' => 'fa fa-clock-o',
                    'text' => 'MON-SAT:8AM TO 9PM',
                    'el_class' => 'hidden-xs'
                ),
                array(
                    'type' => 'dropdown_menu',
                    'icon' => '',
                    'text' => 'CURRENCY',
                    'menu_id' => 130,
                    'el_class' => 'pull-right'
                ),
                array(
                    'type' => 'dropdown_menu',
                    'icon' => '',
                    'text' => 'LANGUAGE',
                    'menu_id' => 131,
                    'el_class' => 'pull-right'
                )
            )
        ),
        /** COLOR  */

        array(
            'key' => 'header_top_background_color',
            'value' => '#f7f7f7'
        ),
        array(
            'key' => 'header_top_text_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'header_top_link_color',
            'value' => '#8a8a8a'
        ),

        /** FOOTER **/
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#131313'
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#8a8a8a'
        ),
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#dcb86c'
        ),
        array(
            'filter_name' => 'negan/filter/footer_column_1',
            'value' => 'footer-column-logo-white'
        ),
        array(
            'filter_name' => 'negan/filter/footer_column_5',
            'value' => 'footer-column-maps'
        ),

        array(
            'key' => 'la_custom_css',
            'value' => '.site-header__nav-primary { background-color: #232324 } .header-v3 .site-header__nav-primary .main-menu > li:first-child > a { padding-left: 0 }'
        ),
        array(
            'key' => 'mm_lv_1_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.footer-top { border-width: 0 }'
        )
    );
}