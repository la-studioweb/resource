<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_15(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'hide'
        ),

        array(
            'key' => 'footer_layout',
            'value' => '1col'
        ),
        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),

        array(
            'key' => 'footer_text_color',
            'value' => '#343538'
        ),

        array(
            'key' => 'footer_link_color',
            'value' => '#343538'
        ),

        array(
            'filter_name' => 'negan/filter/footer_column_1',
            'value' => 'footer-home-15'
        ),
    );
}