<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_07(){
    return array(
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'no'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'hide'
        ),

        /** Color  **/

        array(
            'key' => 'transparency_header_background',
            'value' => array(
                'color' => '#fff'
            )
        ),
        array(
            'key' => 'transparency_header_text_color',
            'value' => '#131313'
        ),
        array(
            'key' => 'transparency_header_link_color',
            'value' => '#131313'
        ),
        array(
            'key' => 'transparency_mm_lv_1_color',
            'value' => '#131313'
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.footer-top { border-width: 0 }'
        )
    );
}