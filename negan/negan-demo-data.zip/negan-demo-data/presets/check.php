<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_check(){
    return array(
        array(
            'key' => 'woocommerce_product_page_design',
            'value' => 3
        ),
//        array(
//            'key' => 'blog_design',
//            'value' => 'list_2'
//        ),
//        array(
//            'key' => 'blog_thumbnail_size',
//            'value' => '570x390'
//        )
//        array(
//            'key' => 'header_layout',
//            'value' => 4
//        ),
//        array(
//            'key' => 'header_transparency',
//            'value' => 'no'
//        ),
//        array(
//            'key' => 'header_full_width',
//            'value' => 'no'
//        ),
//        array(
//            'key' => 'enable_header_top',
//            'value' => 'hide'
//        ),
//        array(
//            'key' => 'use_custom_header_top',
//            'value' => '<div class="header-top-right">[wp_nav_menu menu_id="117"]</div>'
//        ),
//        array(
//            'key' => 'custom_header_text',
//            'value' => '<div class="font-size-14 text-color-three three-font-family">Beautiful WooCommerce WordPress Theme</div>'
//        )
    );
}