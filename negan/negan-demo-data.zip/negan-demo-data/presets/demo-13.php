<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_demo_13(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_layout',
            'value' => 4
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_transparency',
            'value' => 'yes'
        ),
        array(
            'key' => 'enable_header_top',
            'value' => 'hide'
        ),
        array(
            'key' => 'header_show_cart',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_search',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_wishlist',
            'value' => 'no'
        ),
        array(
            'key' => 'header_show_menu_account',
            'value' => 'no'
        ),

        array(
            'key' => 'transparency_header_text_color',
            'value' => '#232324'
        ),
        array(
            'key' => 'transparency_header_link_color',
            'value' => '#232324'
        )
    );
}