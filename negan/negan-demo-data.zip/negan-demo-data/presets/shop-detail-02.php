<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_negan_preset_shop_detail_02(){
    return array(
        array(
            'key' => 'layout_single_product',
            'value' => 'col-2cl'
        ),
        array(
            'key' => 'woocommerce_product_page_design',
            'value' => 1
        ),
        array(
            'key' => 'related_products_columns',
            'value' => array(
                'xlg' => 3,
                'lg' => 3,
                'md' => 3,
                'sm' => 2,
                'xs' => 2,
                'mb' => 1
            )
        ),
        array(
            'key' => 'upsell_products_columns',
            'value' => array(
                'xlg' => 3,
                'lg' => 3,
                'md' => 3,
                'sm' => 2,
                'xs' => 2,
                'mb' => 1
            )
        ),
        array(
            'key' => 'la_custom_css',
            'value' => '.site-main{ padding-top: 70px; padding-bottom: 70px }'
        )
    );
}