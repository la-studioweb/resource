<?php
/**
 * LaStudio Events Uninstall
 *
 * Uninstalling LaStudio Events
 *
 * @author LaStudio
 * @category Core
 * @package LaStudioEvents/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}