<?php
/**
 * LaStudio Discography Uninstall
 *
 * Uninstalling LaStudio Discography
 *
 * @author LaStudio
 * @category Core
 * @package LaStudioDiscography/Uninstaller
 * @version 1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}