<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_camille_preset_about_us_02()
{
    return array(

        array(
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#fff'
        )
    );
}