<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_07(){
    return array(

        /**
         * Settings
         */

		array(
			'key' => 'header_height',
			'value' => '100px',
		),

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'search_1',
				),
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
			),
		),
		
		array(
			'key' => 'enable_header_top',
			'value' => 'yes',
		),
		
		array(
			'key' => 'header_top_elements',
			'value' => array(
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-youtube-play',
					'text' => '',
					'link' => '#',
					'el_class' => 'pull-right margin-left-20'
				),
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-pinterest-p',
					'text' => '',
					'link' => '#',
					'el_class' => 'pull-right'
				),
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-instagram',
					'text' => '',
					'link' => '#',
					'el_class' => 'pull-right'
				),
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-facebook',
					'text' => '',
					'link' => '#',
					'el_class' => 'pull-right'
				),


				
				array(
					'type' => 'dropdown_menu',
					'text' => '<strong>USD <i class="fa-angle-down"></i></strong>',
					'menu_id' => '29',
					'el_class' => 'margin-right-20 pull-right',
				),
				array(
					'type' => 'dropdown_menu',
					'text' => '<strong>ENG <i class="fa-angle-down"></i></strong>',
					'menu_id' => '28',
					'el_class' => 'margin-right-20 pull-right',
				),
				array(
					'type' => 'text',
					'icon' => 'fa-phone',
					'text' => '<strong>(00) 987 6543 21</strong>',
					'el_class' => 'margin-right-10 margin-left-0',
				),
				array(
					'type' => 'text',
					'icon' => 'fa-envelope',
					'text' => '<strong>info@vayneoutfit.com</strong>',
				),
				array(
					'type' => 'link_text',
					'text' => '<strong>Vayne Model has a new look. See the journey of <u>becoming Vayne</u>.</strong>',
					'link' => esc_url(home_url('/')),
					'el_class' => 'text-center pull-none',
				),
			),
		),

        /**
         * Filters
         */



        /**
         * Colors
         */

		array(
			'key' => 'header_top_background_color',
			'value' => 'rgba(0,0,0,0.07)',
		),

    );
}