<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_shop_04_columns(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'layout_archive_product',
            'value' => 'col-1c'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),

        array(
            'key' => 'active_shop_filter',
            'value' => 'on'
        ),

        array(
            'key'   => 'woocommerce_shop_page_columns',
            'value' => array(
                'xlg' => '4',
                'lg' => '4',
                'md' => '3',
                'sm' => '2',
                'xs' => '1',
                'mb' => '1'
            )
        ),

        array(
            'key' => 'product_per_page_allow',
            'value' => '6,12,18'
        ),

        array(
            'key' => 'product_per_page_default',
            'value' => '12'
        ),

        array(
            'key' => 'enable_page_title_subtext',
            'value' => 'yes'
        ),

        array(
            'key' => 'page_title_custom_subtext',
            'value' => 'Nullam varius porttitor augue id rutrum duis vehicula'
        ),
        /**
         * Filters
         */

        array(
            'filter_name' => 'vayne/filter/page_title',
            'value' => '<header><h3 class="page-title">Shop 04 Columns</h3></header>'
        ),

        array(
            'filter_name' => 'vayne/filter/product_per_page_array',
            'filter_func' => function( $value ){
                return '6,12,18';
            },
            'filter_priority'  => 99,
            'filter_args'  => 1
        ),

        /**
         * Colors
         */
        array(
            'key' => 'la_custom_css',
            'value' => '
                @media (min-width: 1300px) {
                    .site-main > .container{
                        padding-left: 40px;
                        padding-right: 40px;
                    }
                }
                @media (min-width: 1400px) {
                    .site-main > .container{
                        padding-left: 60px;
                        padding-right: 60px;
                    }
                }
                @media (min-width: 1500px) {
                    .site-main > .container{
                        padding-left: 80px;
                        padding-right: 80px;
                    }
                }
            '
        )
    );
}