<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_product_fullwidth(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'woocommerce_product_page_design',
            'value' => '3'
        ),

        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),

        /**
         * Filters
         */



        /**
         * Colors
         */

        array(
            'key' => 'la_custom_css',
            'value' => '
                @media (min-width: 1300px) {
                    .site-main > .container{
                        padding-left: 40px;
                        padding-right: 40px;
                    }
                }
                @media (min-width: 1400px) {
                    .site-main > .container{
                        padding-left: 60px;
                        padding-right: 60px;
                    }
                }
                @media (min-width: 1500px) {
                    .site-main > .container{
                        padding-left: 80px;
                        padding-right: 80px;
                    }
                }
				@media (min-width: 1500px){
					.la-single-product-page .product--summary {
						padding-left: 200px;
						max-width: 670px;
					}
				}
            '
        )
    );
}