<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_01(){
    return array(

        /**
         * Settings
         */
		array(
			'key' => 'enable_header_top',
			'value' => 'no',
		),

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
				array(
					'type' => 'aside_header',
				),
			),
		),

		array(
			'key' => 'enable_footer_copyright',
			'value' => 'no',
		),
		
		array(
			'key' => 'footer_copyright',
			'value' => '',
		),

        /**
         * Filters
         */

        /**
         * Colors
         */

    );
}