<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_09(){
    return array(

        /**
         * Settings
         */

		array(
			'key' => 'header_height',
			'value' => '80px',
		),
		
		array(
			'key' => 'header_left_elements',
			'value' => array(
				array(
					'type' => 'search_2',
				),
			),
		),

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
			),
		),

		array(
			'key' => 'subheader_left_elements',
			'value' => array(
				array(
					'type' => 'dropdown_menu',
					'text' => '<strong>ENG <i class="fa-angle-down"></i></strong>',
					'menu_id' => '28',
				),
				array(
					'type' => 'dropdown_menu',
					'text' => '<strong>USD <i class="fa-angle-down"></i></strong>',
					'menu_id' => '29',
				),
			),
		),
		
		array(
			'key' => 'subheader_right_elements',
			'value' => array(
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-facebook',
					'text' => '',
					'link' => '#'
				),
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-instagram',
					'text' => '',
					'link' => '#'
				),
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-pinterest-p',
					'text' => '',
					'link' => '#'
				),
				array(
					'type' => 'link_icon',
					'icon' => 'fa fa-youtube-play',
					'text' => '',
					'link' => '#'
				),
			),
		),

		array(
			'key' => 'enable_header_top',
			'value' => 'yes',
		),
		
		array(
			'key' => 'header_top_elements',
			'value' => array(
				array(
					'type' => 'link_text',
					'text' => '<strong>Vayne Model has a new look. See the journey of <u>becoming Vayne</u>.</strong>',
					'link' => esc_url(home_url('/')),
					'el_class' => 'text-center pull-none',
				),
			),
		),

		array(
			'key' => 'enable_footer_copyright',
			'value' => 'no',
		),
		
		array(
			'key' => 'footer_copyright',
			'value' => '',
		),

        /**
         * Filters
         */

        array(
            'filter_name' => 'vayne/filter/footer_column_1',
            'value' => 'home-4-footer-column-1',
        ),
		
        array(
            'filter_name' => 'vayne/filter/footer_column_2',
            'value' => 'home-4-footer-column-2',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_3',
            'value' => 'home-4-footer-column-3',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_4',
            'value' => 'home-4-footer-column-4',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_5',
            'value' => 'home-4-footer-column-5',
        ),

        /**
         * Colors
         */

		array(
			'key' => 'header_top_background_color',
			'value' => '#000',
		),
		
		array(
			'key' => 'header_top_text_color|header_top_link_color',
			'value' => '#fff',
		),

        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#fff',
            )
        ),

		array(
			'key' => 'footer_space',
            'value' => array(
                'padding_top' => '80px',
                'padding_bottom' => '50px',
				'border_top' => '1px',
				'border_style' => 'solid',
				'border_color' => '#e6e6e6',
            )
		),
		
		array(
			'key' => 'la_custom_css',
			'value' => '.site-footer .widget .widget-title{margin-bottom: 20px;}.site-footer .menu li{margin-bottom:2px;}@media (min-width: 992px){
				.la-footer-5col32223 .footer-column-1.col-md-3{
					width: 20%;
				}
				.la-footer-5col32223 .footer-column-2.col-md-2{
					width: 20%;
				}
				.la-footer-5col32223 .footer-column-3.col-md-2{
					width: 20%;
				}
				.la-footer-5col32223 .footer-column-4.col-md-2{
					width: 20%;
				}
				.la-footer-5col32223 .footer-column-5.col-md-2{
					width: 20%;
				}				
			}',
		),

    );
}