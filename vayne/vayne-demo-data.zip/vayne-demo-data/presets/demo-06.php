<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_06(){
    return array(

        /**
         * Settings
         */

		array(
			'key' => 'header_left_elements',
			'value' => array(
				array(
					'type' => 'aside_header',
					'text' => 'MENU',
					'el_class' => 'margin-right-20',
				),
				array(
					'type' => 'search_2',
				),
			),
		),

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'dropdown_menu',
					'text' => '<strong>ENG <i class="fa-angle-down"></i></strong>',
					'menu_id' => '28',
					'el_class' => 'margin-right-20',
				),
				array(
					'type' => 'dropdown_menu',
					'text' => '<strong>USD <i class="fa-angle-down"></i></strong>',
					'menu_id' => '29',
					'el_class' => 'margin-right-40',
				),
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
			),
		),

        /**
         * Filters
         */

        array(
            'filter_name' => 'vayne/filter/footer_column_1',
            'value' => '',
        ),
		
        array(
            'filter_name' => 'vayne/filter/footer_column_2',
            'value' => '',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_3',
            'value' => '',
        ),

        /**
         * Colors
         */

        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#fff',
            )
        ),

		array(
			'key' => 'footer_space',
            'value' => array(
                'padding_top' => '0px',
                'padding_bottom' => '0px'
            )
		),
		
		array(
			'key' => 'la_custom_css',
			'value' => '.footer-bottom .footer-bottom-inner{margin-bottom: 50px;}',
		),

    );
}