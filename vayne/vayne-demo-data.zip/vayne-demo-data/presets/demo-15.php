<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_15(){
    return array(

        /**
         * Settings
         */

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
				array(
					'type' => 'aside_header',
				),
			),
		),

        /**
         * Filters
         */

        /*array(
            'filter_name' => 'vayne/filter/footer_column_1',
            'value' => 'home-11-footer-column-1'
        ),*/

        /**
         * Colors
         */


    );
}