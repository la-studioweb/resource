<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_11(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
				array(
					'type' => 'aside_header',
				),
			),
        ),

        /**
         * Colors
         */


    );
}