<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_10(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'search_1',
				),
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
			),
        ),

        array(
            'key' => 'footer_layout',
            'value' => '1col'
        ),
        array(
            'key' => 'enable_footer_copyright',
            'value' => 'no'
        ),

        /**
         * Filters
         */

        array(
            'filter_name' => 'vayne/filter/footer_column_1',
            'value' => '',
        ),
		
        array(
            'filter_name' => 'vayne/filter/footer_column_2',
            'value' => '',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_3',
            'value' => '',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_4',
            'value' => '',
        ),

        array(
            'filter_name' => 'vayne/filter/footer_column_5',
            'value' => '',
        ),

        /**
         * Colors
         */

        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => 'transparent',
            )
        ),

		array(
			'key' => 'footer_space',
            'value' => array(
                'padding_top' => '0px',
                'padding_bottom' => '0px'
            )
		),

    );
}