<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_03(){
    return array(

        /**
         * Settings
         */

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
				array(
					'type' => 'aside_header',
				),
			),
		),

        /**
         * Filters
         */

        array(
            'filter_name' => 'vayne/filter/footer_column_1',
            'value' => 'home-3-footer-column-1',
        ),

        /**
         * Colors
         */

        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#fff',
            )
        ),

		array(
			'key' => 'footer_space',
            'value' => array(
                'padding_top' => '60px',
                'padding_bottom' => '20px'
            )
		),
		
		array(
			'key' => 'la_custom_css',
			'value' => '.footer-bottom{padding-bottom: 30px;}',
		),

    );
}