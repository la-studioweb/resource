<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_demo_12(){
    return array(

        /**
         * Settings
         */

		array(
			'key' => 'header_access_icon',
			'value' => array(
				array(
					'type' => 'wishlist',
				),
				array(
					'type' => 'cart',
				),
				array(
					'type' => 'aside_header',
				),
			),
		),

		array(
			'key' => 'enable_footer_copyright',
			'value' => 'no',
		),
		
		array(
			'key' => 'footer_copyright',
			'value' => '',
		),

        /**
         * Filters
         */

        array(
            'filter_name' => 'vayne/filter/footer_column_1',
            'value' => 'home-1-footer-column-1',
        ),
		
        array(
            'filter_name' => 'vayne/filter/footer_column_2',
            'value' => 'home-1-footer-column-2',
        ),

        /**
         * Colors
         */

        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#fff',
            )
        ),

		array(
			'key' => 'footer_space',
            'value' => array(
                'padding_top' => '100px',
                'padding_bottom' => '70px'
            )
		),

    );
}