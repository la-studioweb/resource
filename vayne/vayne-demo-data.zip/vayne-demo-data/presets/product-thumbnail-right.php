<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_vayne_preset_product_thumbnail_right(){
    return array(

        /**
         * Settings
         */

        array(
            'key' => 'woocommerce_product_page_design',
            'value' => '2b'
        ),

        /**
         * Filters
         */



        /**
         * Colors
         */

        array(
            'key' => 'la_custom_css',
            'value' => ''
        )
    );
}