<?php

function la_vayne_get_demo_array($dir_url, $dir_path){


    $default_image_setting = array(
        'shop_catalog_image_size' => array(
            'width' => 570,
            'height' => 640,
            'crop' => true
        ),
        'shop_single_image_size' => array(
            'width' => 600,
            'height' => 600,
            'crop' => true
        ),
        'shop_thumbnail_image_size' => array(
            'width' => 180,
            'height' => 180,
            'crop' => true
        ),
        'thumbnail_size_w' => 0,
        'thumbnail_size_h' => 0,
        'medium_size_w' => 0,
        'medium_size_h' => 0,
        'medium_large_size_w' => 0,
        'medium_large_size_h' => 0,
        'large_size_w' => 0,
        'large_size_h' => 0
    );

    $default_menu = array(
        'main-nav'              => 'Primary Navigation',
        'mobile-nav'            => 'Primary Navigation',
        'aside-nav'             => 'Primary Navigation'
    );

    $default_page = array(
        'page_for_posts' 	            => 'Blog',
        'woocommerce_shop_page_id'      => 'Shop',
        'woocommerce_cart_page_id'      => 'Cart',
        'woocommerce_checkout_page_id'  => 'Checkout',
        'woocommerce_myaccount_page_id' => 'My Account',
        'yith_wcwl_wishlist_page_id'    => 'Wishlist'
    );

    $slider = $dir_path . 'Slider/';
    $content = $dir_path . 'Content/';
    $widget = $dir_path . 'Widget/';
    $setting = $dir_path . 'Setting/';
    $preview = $dir_url;


    $demo_data = array();

    for( $i = 1; $i <= 15; $i ++ ){
        $id = $i;
        if( $i < 10 ) {
            $id = '0'. $i;
        }

        $value = array();
        $value['title']             = 'Demo ' . $id;
        $value['category']          = 'demo';
        $value['demo_preset']       = 'demo-' . $id;
        $value['demo_url']          = 'http://vayne.la-studioweb.com/demo-' . $id . '/';
        $value['preview']           = $preview  .   'demo-' . $id . '.jpg';
        $value['option']            = $setting  .   'demo-' . $id . '.json';
        $value['widget']            = $widget   .   'widget-' . $id . '.json';
        $value['content']           = $content  .   'data-sample.xml';

        $value['pages']             = array_merge(
            $default_page,
            array(
                'page_on_front' => 'Demo ' . $id
            )
        );

        $value['menu-locations']    = array_merge(
            $default_menu,
            array(

            )
        );
        $value['other_setting']    = array_merge(
            $default_image_setting,
            array(

            )
        );

        if( $i != 3 && $i != 5 && $i != 8 && $i != 9 && $i != 10 || $i != 11 && $i != 15 ){
            $value['slider']            = $slider   .   'demo-'. $id .'.zip';
        }

        if( $i == 9){
            $value['slider']            = array(
                $slider   .   'demo-09.zip',
                $slider   .   'intro-09.zip'
            );
        }

        $demo_data['home-'. $id] = $value;
    }

    return $demo_data;
}