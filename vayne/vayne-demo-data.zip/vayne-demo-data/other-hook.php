<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}


add_filter('woocommerce_product_related_posts_relate_by_category', '__return_false');
add_filter('woocommerce_product_related_posts_relate_by_tag', '__return_false');
add_filter('woocommerce_product_related_posts_force_display', '__return_true');


add_filter('body_class', 'vayne_preset_add_body_classes');

function vayne_preset_add_body_classes( $class ){
    $class[] = 'isLaWebRoot';
    return $class;
}

add_action( 'pre_get_posts', 'vayne_preset_change_blog_posts' );
function vayne_preset_change_blog_posts( $query ){

    if($query->is_home() && $query->is_main_query()){

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-01'){
            $query->set( 'category__in', array(58) );
            $query->set( 'posts_per_page', 5 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-02'){
            $query->set( 'category__in', array(59) );
            $query->set( 'posts_per_page', 5 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-03'){
            $query->set( 'posts_per_page', 16 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-04'){
            $query->set( 'posts_per_page', 12 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-05'){
            $query->set( 'category__in', array(62,58,59) );
            $query->set( 'posts_per_page', 8 );
        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'blog-06'){
            $query->set( 'category__in', array(62,58,59) );
            $query->set( 'posts_per_page', 6 );
        }

    }

}

add_filter('single_product_archive_thumbnail_size', 'vayne_preset_modify_thumbnail_for_shop_masonry', 99 );
function vayne_preset_modify_thumbnail_for_shop_masonry( $size ){
    global $vayne_loop, $woocommerce_loop;
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'shop-masonry'){
        $idx = absint($woocommerce_loop['loop']);
        if($idx < 1){
            $idx = 1;
        }
        if( in_array($idx, array(1,4,7,10,13,16,19)) ){
            $vayne_loop['image_size'] = array(400,0);
            return array(400,0);
        }
        if(in_array($idx, array(2,5,8,11,14,17,20))){
            $vayne_loop['image_size'] = array(400,470);
            return array(400,470);
        }
        if(in_array($idx, array(3,6,9,12,15,18))){
            $vayne_loop['image_size'] = array(400,420);
            return array(400,420);
        }
    }

    return $size;
}


add_action('woocommerce_before_shop_loop_item_title', 'vayne_preset_after_modify_thumbnail_for_shop_masonry', 37);
function vayne_preset_after_modify_thumbnail_for_shop_masonry(){
    remove_all_filters('vayne/filter/image_helper/crop', 101);
}

add_filter('is_active_sidebar', 'vayne_modify_single_custom_sidebar', 10, 2);
function vayne_modify_single_custom_sidebar( $is_active_sidebar, $index ){
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'shop-detail-02' && $index == 'la-p-s-block-1'){
        return false;
    }
    return $is_active_sidebar;
}

add_filter('woocommerce_output_related_products_args', 'vayne_modify_woocommerce_output_related_products_args');
function vayne_modify_woocommerce_output_related_products_args( $args ){
    if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'shop-detail-02'){
        return array(
            'posts_per_page' 	=> 3,
            'columns' 			=> 3,
            'orderby'           => 'rand'
        );
    }
    return $args;
}



add_action( 'woocommerce_product_query', 'vayne_demo_product_query', 20);

function vayne_demo_product_query( $q ){

    if(is_shop()){

//        $tax_query = (array) $q->get( 'tax_query' );
//
//        $tax_query[] = array(
//            'taxonomy' => 'product_tag',
//            'field' => 'term_id',
//            'terms' => array( 75 ),
//            'operator' => 'IN'
//        );

        //$q->set( 'tax_query', $tax_query );

//        if(!isset($_GET['orderby']) || ( isset($_GET['orderby']) && $_GET['orderby'] != 'date' )){
//            $q->set( 'orderby', 'date' );
//            $q->set( 'order', 'ASC' );
//        }

        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'shop-masonry'){
            $q->set( 'posts_per_page', 20 );
        }
        if(isset($_GET['la_preset']) && $_GET['la_preset'] == 'shop-metro'){
            $q->set( 'posts_per_page', 12 );
            $tax_query = (array) $q->get( 'tax_query' );
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => array( 76 ),
                'operator' => 'IN'
            );

            $q->set( 'tax_query', $tax_query );
            $q->set( 'orderby', 'date' );
            $q->set( 'order', 'DESC' );
        }
    }

}