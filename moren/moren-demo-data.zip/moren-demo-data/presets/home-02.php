<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_moren_preset_home_02()
{
    return array(

        array(
            'key'   => 'primary_color',
            'value' => '#0f6cad'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '40px'
            )
        ),
        array(
            'key' => 'enable_footer_top',
            'value' => 'no'
        ),

        array(
            'key' => 'footer_heading_color',
            'value' => '#252c34'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#687076'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#687076'
        ),
         array(
            'key' => 'footer_link_hover_color',
            'value' => '#0f6cad'
        ),
        array(
            'key' => 'footer_copyright_link_color',
            'value' => '#0f6cad'
        ), 
        array(
            'key' => 'footer_copyright_link_hover_color',
            'value' => '#0f6cad'
        ),

        array(
            'key' => 'main_font',
            'value' => array(
                'family' => 'Raleway',
                'font' => 'google',
                'variant' => array('500','600','700','800','900')
            )
        ),
        array(
            'key' => 'secondary_font',
            'value' => array(
                'family' => 'Raleway',
                'font' => 'google',
                'variant' => array('500','600','700','800','900')
            )
        ),

        array(
            'filter_name' => 'moren/filter/footer_column_1',
            'value' => 'footer-column-01-home-02'
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_2',
            'value' => 'footer-column-02-home-02'
        ),

        array(
            'filter_name' => 'moren/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                                body{
                                    background-color: #F6F6F6;
                                }
                                #la_full_page #colophon {
                                    margin-left: auto;
                                    margin-right: auto;
                                }
                                .footer-bottom .footer-bottom-inner {
                                    padding: 5px 0 15px;
                                }
                                .site-footer{
                                    border: none;
                                    background-color: #EEEEEE;
                                    
                                }
                                .site-footer .footer-top{
                                    font-weight: 500;
                                }
                                .footer-bottom{
                                    background-color: #252C34;
                                }
                                .widget_yikes_easy_mc_widget{
                                    max-width: 280px;
                                }
                                .site-footer .social-media-link.style-default a{
                                    background-color: #3B424A;
                                    border: none;
                                    opacity: 1;
                                    
                                }
                                .site-footer .social-media-link.style-default a i{
                                        color: #fff;
                                }
                                .footer-bottom-inner{
                                    color: #90979c;
                                }
                                .footer-top .widget .widget-title{
                                    font-weight: 800;
                                    font-size: 16px;
                                }

                                ';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
    );
}