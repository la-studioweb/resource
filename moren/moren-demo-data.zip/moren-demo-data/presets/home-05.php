<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_moren_preset_home_05()
{
    return array(
        array(
            'key'   => 'primary_color',
            'value' => '#FBBB1B'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),

        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '40px'
            )
        ),
        array(
            'key' => 'enable_footer_top',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#252634'
            )
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_1',
            'value' => 'footer-column-01-home-05'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#b5b7c4'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#b5b7c4'
        ), 
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#FBBB1B'
        ),
        array(
            'key' => 'footer_copyright_link_color',
            'value' => '#FBBB1B'
        ), 
        array(
            'key' => 'footer_copyright_link_hover_color',
            'value' => '#FBBB1B'
        ),
        array(
            'filter_name' => 'moren/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                                @media(min-width: 1366px){
                                   
                                    .la-footer-3col444 .footer-column-2  {
                                        padding-left: 70px;
                                    }
                                }
                        ';
                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
        /*array(
            'key' => 'footer_copyright',
            'value' => '
<div class="row">
    <div class="col-xs-12 text-center">
        Copyright 2016 Moren. All Right Reserved. Designed by LA STUDIO
    </div>
</div>
'
        ),*/
    );
}