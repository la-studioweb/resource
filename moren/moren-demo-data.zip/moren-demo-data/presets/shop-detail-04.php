<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_moren_preset_shop_detail_04()
{
    return array(

        array(
            'key' => 'woocommerce_product_page_design',
            'value' => '4'
        )

    );
}