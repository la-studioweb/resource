<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}

function la_moren_preset_home_04()
{
    return array(

        array(
            'key'   => 'header_layout',
            'value' => 'pre-header-7'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '4col3333'
        ),
        array(
            'key'   => 'primary_color',
            'value' => '#d70c1a'
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_1',
            'value' => 'footer-column-01-home-04'
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_2',
            'value' => 'footer-column-02-home-04'
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_3',
            'value' => 'footer-column-03-home-04'
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_4',
            'value' => 'footer-column-04-home-04'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#242633'
            )
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#8c8d90'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#dde3e7'
        ), 
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#d70c1a'
        ),
        array(
            'key' => 'footer_copyright_link_color',
            'value' => '#fff'
        ), 
        array(
            'key' => 'footer_copyright_link_hover_color',
            'value' => '#d70c1a'
        ),
        array(
            'filter_name' => 'moren/setting/option/get_single',
            'filter_func' => function ($value, $key) {
                if ($key == 'la_custom_css') {
                    $value .= '

                            @media(min-width: 991px){
                                .la-footer-4col3333 .footer-column-3 ,
                                .la-footer-4col3333 .footer-column-2 ,
                                .la-footer-4col3333 .footer-column-1 {
                                    width: 33.33333%;
                                }
                                .la-footer-4col3333 .footer-column-4 {
                                    width: 100%;
                                    border-top: 1px solid rgba(225,225,225,0.1);
                                    margin-top: 30px;
                                    padding-top: 50px;
                                }
                            }
                           
                            .site-footer{
                                border: none;
                            }
                            .footer-top-area .btn-wrapper .btn{
                                background-color: #242633;
                                border-radius: 0;
                                border: none;
                            }
                            .footer-top-area .btn-wrapper .btn:hover{
                                background-color: #4A4F6F;
                            }
                            .site-footer .footer-top{
                                padding-bottom: 60px;
                            }
                            .footer-top-area .container{
                                background-image: none;
                            }
                            .site-footer ul.menu li {
                                display: inline-block;
                                width: 49%;
                            }
                            .site-footer .widget .widget-title span{
                                border-bottom: 1px solid #d70c1a;
                                padding-bottom: 18px;
                            }
                            .widget_contact_info .la-contact-info{
                                display: flex;
                                justify-content: center;
                            }
                            .widget_contact_info .la-contact-info .la-contact-item{
                                margin: 0 15px;
                            }
                            .widget_contact_info .la-contact-item.la-contact-phone{
                                order: 2;
                            }
                            .widget_contact_info .la-contact-item.la-contact-email{
                                order: 1;
                            }
                            .widget_contact_info .la-contact-info .la-contact-item a{ 
                                color: #8c8d90;
                            }
                            .site-footer .social-media-link.style-default a{
                                border-radius: 50%;
                                background-color: #303644;
                                border: none;
                                opacity: 1;
                                -webkit-opacity: 1;
                                width: 32px;
                                height: 32px;
                                line-height: 32px;
                            }
                            @media(max-width: 991px){
                                .widget_contact_info .la-contact-info{
                                    display: block;
                                }
                                .widget_contact_info .la-contact-info .la-contact-item{
                                    margin-top: 20px;
                                    margin-bottom: 20px;
                                }
                                .footer-top-area .btn-wrapper .btn{
                                    min-width: auto;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                }
                            }
                        ';
                }
                return $value;
            },
            'filter_priority' => 10,
            'filter_args' => 2
        ),);
}