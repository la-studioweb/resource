<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_moren_preset_home_06()
{
    return array(


        array(
            'key'   => 'primary_color',
            'value' => '#FBBB1B'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '4col3333'
        ),
        array(
            'key' => 'footer_space',
            'value' => array(
                'padding_top' => '55px'
            )
        ),
        array(
            'key' => 'enable_footer_top',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#242633'
            )
        ),
        array(
            'key' => 'footer_copyright_background_color',
            'value' => '#242633'
        ),

        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_text_color',
            'value' => '#b5b7c4'
        ),
        array(
            'key' => 'footer_link_color',
            'value' => '#b5b7c4'
        ), 
        array(
            'key' => 'footer_link_hover_color',
            'value' => '#FBBB1B'
        ),

        
        array(
            'filter_name' => 'moren/filter/footer_column_1',
            'value' => 'f-col-4'
        ),  
        array(
            'filter_name' => 'moren/filter/footer_column_3',
            'value' => 'footer-column-instagram'
        ),
        array(
            'filter_name' => 'moren/filter/footer_column_4',
            'value' => 'f-col-3'
        ),
    
        array(
            'filter_name' => 'moren/setting/option/get_single',
            'filter_func' => function( $value, $key ){
                if( $key == 'la_custom_css'){
                    $value .= '
                                #la_full_page #colophon {
                                    margin-left: auto;
                                    margin-right: auto;
                                }
                                .site-footer .footer-top{
                                    max-width: 100%;
                                }
                                .refer-testimonial-item .loop_info:after{
                                    border-top: 5px solid #FBBB1B;
                                }
                                .site-footer .social-media-link.style-default a{
                                    opacity: 0.3;
                                }
                                .site-footer .social-media-link.style-default a i{
                                    color: #969696;
                                }
                                .site-footer .footer-top{
                                    padding-bottom: 0;
                                }
                                @media(min-width: 1366px){
                                    .la-footer-4col3333 .footer-column-1 {
                                        width: 16.66667%;
                                    }
                                    .la-footer-4col3333 .footer-column-2 {
                                        width: 16.66667%;
                                    }
                                    .la-footer-4col3333 .footer-column-3 {
                                        width: 41.66667%;
                                        padding: 0 50px;
                                    }
                                    .la-footer-4col3333 .footer-column-4{
                                        width: 25%;
                                    }
                                }
                                #gallery-1{
                                    margin: 0 0 0 -12px !important;
                                    text-align: left;
                                }
                                .gallery .gallery-item a{
                                    box-shadow: none;
                                    border: none;
                                    background: none;
                                }
                                .isLaWebRoot .la-footer-5col32223 .footer-column-5 .footer-column-inner {
                                    width: 100%;
                                    float: none;
                                }
                                .la-footer-5col32223 .footer-column-1 .footer-column-inner {
                                    width: 300px;
                                }
                                .site-footer{
                                    border-top: 3px solid #FBBB1B;
                                }
                                .footer-bottom .footer-bottom-inner{
                                    border-top: 1px solid rgba(225,225,225,0.1);
                                    padding: 50px 0;
                                    line-height: 70px;
                                }
                                .footer-bottom-inner .logo-footer{
                                            float: left;
                                    }
                                .copyright-social{
                                    text-align: right;
                                }
                                @media(max-width: 991px){
                                    .site-footer .social-media-link.style-default a{
                                        width: 22px;
                                    }
                                    .copyright-text{
                                        font-size: 11px;
                                    }
                                }
                                @media(max-width: 767px){
                                    .copyright-social{
                                        text-align: center;
                                    }
                                    .footer-bottom-inner .logo-footer{
                                            float: none;
                                    }
                                }
                                ';

                }
                return $value;
            },
            'filter_priority'  => 10,
            'filter_args'  => 2
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '
            <div class="row">
                <div class="col-sm-3 col-xs-12 text-center ">
                    <img class="logo-footer" src="https://moren.la-studioweb.com/wp-content/uploads/2018/12/footer-home-04.png">
                </div>
                <div class="col-sm-6 col-xs-12 text-center copyright-text">   Copyright 2016 Moren. All Right Reserved. Designed by LA STUDIO</div>
                <div class="col-sm-3 col-xs-12  copyright-social">   
                    <div class="social-media-link style-default " style="color: #181818;"><a href="#" class="facebook" title="Facebook" target="_blank" rel="nofollow"><i class="fa fa-facebook"></i></a><a href="#" class="twitter" title="Twitter" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i></a><a href="#" class="pinterest" title="Pinterest" target="_blank" rel="nofollow"><i class="fa fa-pinterest-p"></i></a><a href="#" class="linked-in" title="Linked In" target="_blank" rel="nofollow"><i class="fa fa-linkedin-square"></i></a><a href="#" class="behance" title="Behance" target="_blank" rel="nofollow"><i class="fa fa-behance"></i></a></div>
                    </div>
                </div>
            </div>
        '
        ),
    );
}